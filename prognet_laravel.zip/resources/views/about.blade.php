@extends('master')
@section('title','About')
@section('content')
@include('jumbotron')
<div class="container">
  <div class="row">
    <div class="col">
        I Putu Angga Darma Putra <br>
        1705551054
    </div>
  </div>
</div>
@endsection