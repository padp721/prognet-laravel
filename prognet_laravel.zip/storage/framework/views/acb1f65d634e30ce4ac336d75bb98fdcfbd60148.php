<?php $__env->startSection('title','Edit Data Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:1%; margin-bottom:5%;">
  <div class="row">
    <div class="col">
      <div class="card">
          <div class="card-header ">
              <h1 class="float-left">Input Data Anda</h1>
              <div class="clearfix"></div>
          </div>
        <div class="card-body">
          <form method="post">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e($error); ?>

          </div>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
              <input type="text" class="form-control" id="nim" name="nim" placeholder="NIM" maxlength="10" value="<?php echo e($data->nim); ?>" required>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama" value="<?php echo e($data->nama); ?>" required>
            </div>
            <div class="form-group">
              <textarea  type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat" rows="3" required><?php echo e($data->alamat); ?></textarea>
            </div>
            <div class="form-group" id="sandbox-container">
              <input type="text" class="form-control" placeholder="Tanggal Lahir" id="tgl" name="tgl" value="<?php echo e($data->tgl_lahir); ?>" autocomplete="off" required>
            </div>
            <div class="form-group">
              <select class="form-control" id="agama" name="agama" required>
                <option value="">Agama</option>
                <option value="1" <?php if($data->agama == '1'): ?>
                    selected
                  <?php endif; ?>>Hindu</option>
                <option value="2" <?php if($data->agama == '2'): ?>
                  selected
                <?php endif; ?>>Islam</option>
                <option value="3" <?php if($data->agama == '3'): ?>
                  selected
                <?php endif; ?>>Kristen</option>
                <option value="4" <?php if($data->agama == '4'): ?>
                  selected
                <?php endif; ?>>Protestan</option>
                <option value="5" <?php if($data->agama == '5'): ?>
                  selected
                <?php endif; ?>>Budha</option>
                <option value="6" <?php if($data->agama == '6'): ?>
                  selected
                <?php endif; ?>>Kong Hu Chu</option>
              </select>
            </div>
            <div class="form-group">
              Jenis Kelamin :<br>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" id="jk" name="jk" value="L"  <?php if($data->jk == 'L'): ?>
                  checked
                <?php endif; ?>>Laki - Laki
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" id="jk" name="jk" value="P"  <?php if($data->jk == 'P'): ?>
                  checked
                <?php endif; ?>>Perempuan
                </label>
              </div>
            </div>
            <div class="form-group">
              Hobi :<br>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="1" name="hobi[]" <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($x->hobi == 1): ?>
                        checked
                    <?php endif; ?>                      
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Kuliah
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="2" name="hobi[]" <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($x->hobi == 2): ?>
                      checked
                  <?php endif; ?>                      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Tidur
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="3" name="hobi[]" <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($x->hobi == 3): ?>
                      checked
                  <?php endif; ?>                      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Main Mobile Legends
                </label>
              </div>
              <br>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="4" name="hobi[]" <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($x->hobi == 4): ?>
                      checked
                  <?php endif; ?>                      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Main PUBG
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="5" name="hobi[]" <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($x->hobi == 5): ?>
                      checked
                  <?php endif; ?>                      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Lain - Lain
                </label>
              </div>
            </div>
            <div class="form-group">
            <center><input type="submit" class="btn btn-success" name="submit" value="Submit" style="width : 100%;"></center>
            </div>
            <div class="form-group">
				<a href="../../mahasiswa" class="btn btn-primary" role="button" style="width:100%">Kembali</a>
			</div>
          </form>
        </div>
      </div>
    </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>