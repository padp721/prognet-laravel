<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 3%;">
  <div class="row">
  <div class="col"></div>
    <div class="col-md-5">
      <div class="card fade-in">
        <div class="card-body">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h1>Daftar User Baru</h1>
                <form method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Nama" value="<?php echo e(old('name')); ?>" required>
                              </div>
                              <div class="form-group">
                                  <input type="email" class="form-control" id="email" name="email" placeholder="E-Mail" value="<?php echo e(old('email')); ?>" required>
                                </div>
                              <div class="form-group">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                              </div>
                              <div class="form-group">
                                  <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Konfirmasi Password" required>
                                </div>
                    <div class="form-group">
                        <center><input type="submit" class="btn btn-success" name="daftar" value="Sign Up" style="width : 100%;"></center>
                    </div>
                    <div class="form-group">
                        <center><a href="login" class="btn btn-primary" style="width : 100%;">Sign In</a></center>
                    </div>
                </form>
        </div>
      </div>
    </div>
  </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>