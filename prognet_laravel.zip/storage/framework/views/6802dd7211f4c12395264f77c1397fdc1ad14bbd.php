<nav class="navbar navbar-expand-sm bg-dark fixed-top">
    <a class="navbar-brand" href="#" style="color:white;">PADP721</a>
    <span class="navbar-text ml-auto" style="color:white;">I Putu Angga Darma Putra - 1705551054</span>
</nav>