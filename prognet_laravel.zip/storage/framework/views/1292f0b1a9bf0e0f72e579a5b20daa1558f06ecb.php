<?php $__env->startSection('title','About'); ?>
<?php echo $__env->make('jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col">
        I Putu Angga Darma Putra <br>
        1705551054
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>