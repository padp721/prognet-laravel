<nav class="navbar navbar-expand-sm bg-dark">
    <a class="navbar-brand" href="/" style="color:white;">PADP721</a>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item nav-link" style="color:white;">
            I Putu Angga Darma Putra - 1705551054
        </li>
        <?php if(Auth::check()): ?>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown" style="color:white;">Halo, <?php echo e(Auth::user()->name); ?>!</a>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="logout" class="dropdown-item">Logout</a>
            </div>
        </li>
        <?php else: ?>
            <?php if (! (Request::is('login') || Request::is('daftar'))): ?>
                <script>window.location = "login";</script>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</nav>