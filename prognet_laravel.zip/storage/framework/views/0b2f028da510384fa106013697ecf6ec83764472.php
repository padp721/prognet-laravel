<?php $__env->startSection('title','Data Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="margin-top: 7%; margin-bottom:5%;">
<div class="row">
        <div class="col">
          <div class="card">
            <div class="card-body">
            <div class="row">
            <div class="col-6">
            <h5>Halo, Kau!</h5>
            </div>
            <div class="col-6 text-right">
            <a href="logout.php" class="btn btn-danger btn-sm text-right" role="button">Logout</a>
            </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      <br>
  <div class="row">
    <div class="col">
            <div class="card">
                    <div class="card-header ">
                        <h1 class="float-left">Daftar Mahasiswa</h1>
                        <div class="clearfix"></div>
                    </div>
              <div class="card-body">
                <a href="mahasiswa/tambah" class="btn btn-primary" role="button">Tambah Data Mahasiswa</a>
                <?php if(session('status')): ?>
                <br><br>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <table class="table table-hover" style="margin-top:2%; text-align: center;">
                  <thead class="thead-dark">
                    <tr>
                      <th>No</th>
                      <th>NIM</th>
                      <th>Nama</th>
                      <th>Alamat</th>
                      <th>Tanggal Lahir</th>
                      <th>Agama</th>
                      <th>Jenis Kelamin</th>
                      <th>Hobi</th>
                      <th colspan="2">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if($data->isEmpty()): ?>
                        <tr>
                            <td colspan="9"><center><h3>Tidak ada data!</h3></center></td>
                        </tr>
                     <?php else: ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$no); ?></td>
                                <td><?php echo e($row->nim); ?></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->alamat); ?></td>
                                <td><?php echo e($row->tgl_lahir); ?></td>
                                <td>
                                  <?php if($row->agama == '1'): ?>
                                      Hindu
                                  <?php elseif($row->agama == '2'): ?>
                                      Islam
                                  <?php elseif($row->agama == '3'): ?>
                                      Kristen
                                  <?php elseif($row->agama == '4'): ?>
                                      Protestan
                                  <?php elseif($row->agama == '5'): ?>
                                      Budha
                                  <?php elseif($row->agama == '6'): ?>
                                      Kong Hu Chu
                                  <?php else: ?>
                                      Atheis
                                  <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($row->jk == 'L'): ?>
                                        Laki - Laki
                                    <?php else: ?>
                                        Perempuan
                                    <?php endif; ?>
                                </td>
                                <td>Kosong</td>
                                <td><a href="<?php echo e(action('MhsController@edit', $row->nim)); ?>" class="btn btn-success btn-sm" role="button">Ubah</a></td>
                                <td>
                                  <form method="POST" action="<?php echo e(action('MhsController@destroy', $row->nim)); ?>">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-danger btn-sm" role="button" value="Hapus">
                                  </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>