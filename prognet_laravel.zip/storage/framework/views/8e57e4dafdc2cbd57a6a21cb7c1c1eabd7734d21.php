<?php $__env->startSection('title','Tambah Data Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:1%; margin-bottom:5%;">
  <div class="row">
    <div class="col">
      <div class="card">
          <div class="card-header ">
              <h1 class="float-left">Input Data Anda</h1>
              <div class="clearfix"></div>
          </div>
        <div class="card-body">
          <form method="post">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e($error); ?>

          </div>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(session('nim')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <?php echo e(session('nim')); ?>

                        </div>
                    <?php endif; ?>
            <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
              <input type="text" class="form-control" id="nim" name="nim" placeholder="NIM" maxlength="10" value="<?php echo e(old('nim')); ?>" required>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama" value="<?php echo e(old('nama')); ?>" required>
            </div>
            <div class="form-group">
              <textarea  type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat" value="<?php echo e(old('alamat')); ?>" rows="3" required></textarea>
            </div>
            <div class="form-group" id="sandbox-container">
              <input type="text" class="form-control" placeholder="Tanggal Lahir" id="tgl" name="tgl" autocomplete="off" value="<?php echo e(old('tgl')); ?>" required>
            </div>
            <div class="form-group">
              <select class="form-control" id="agama" name="agama" required>
                <option value="">Agama</option>
                <option value="1">Hindu</option>
                <option value="2">Islam</option>
                <option value="3">Kristen</option>
                <option value="4">Protestan</option>
                <option value="5">Budha</option>
                <option value="6">Kong Hu Chu</option>
              </select>
            </div>
            <div class="form-group">
              Jenis Kelamin :<br>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" id="jk" name="jk" value="L">Laki - Laki
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" id="jk" name="jk" value="P">Perempuan
                </label>
              </div>
            </div>
            <div class="form-group">
              Hobi :<br>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="1" name="hobi[]">Kuliah
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="2" name="hobi[]">Tidur
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="3" name="hobi[]">Main Mobile Legends
                </label>
              </div>
              <br>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="4" name="hobi[]">Main PUBG
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="5" name="hobi[]">Lain - Lain
                </label>
              </div>
            </div>
            <div class="form-group">
            <center><input type="submit" class="btn btn-success" name="submit" value="Submit" style="width : 100%;"></center>
            </div>
            <div class="form-group">
				<a href="../../mahasiswa" class="btn btn-primary" role="button" style="width:100%">Kembali</a>
			</div>
          </form>
        </div>
      </div>
    </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>